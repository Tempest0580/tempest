import requests
url = 'http://dl5.lavinmovie.net/Movies/1999/'
url = requests.get(url).content
print url