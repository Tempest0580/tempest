import requests
url = 'https://ww.gomovies.sc/movie/aquaman-2018-watch-online/watching/?ep=2'
url = requests.get(url).content
print url