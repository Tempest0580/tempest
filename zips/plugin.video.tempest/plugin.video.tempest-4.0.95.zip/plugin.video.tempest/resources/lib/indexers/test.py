import requests, re
url = 'https://myvideolinks.net'
url = requests.get(url).content
url = re.compile('<a href="(https://myvideolinks.net/.+?)"').findall(url)[0]
url = requests.get(url).content
print url