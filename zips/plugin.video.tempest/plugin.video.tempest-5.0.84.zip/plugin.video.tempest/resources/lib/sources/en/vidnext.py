# -*- coding: utf-8 -*-
# Need to work on Tvshows a little more
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, urllib, urlparse, json
import traceback
from resources.lib.modules import log_utils
from resources.lib.modules import client
from resources.lib.modules import source_utils, control


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['vidnext.net']
        self.base_link = 'https://vidnext.net'
        self.search_link = '/search.html?keyword=%s'
        self.search_link2 = '/search.html?keyword=%s+season+%s+episode+%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            items = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            hdlr = '%s - Season %s Episode %s' % (data['tvshowtitle'], data['season'], data['episode'])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            if 'tvshowtitle' in data:
                url = self.search_link2 % (title.replace(' ', '+'), data['season'], data['episode'])
            else:
                url = self.search_link2 % (title.replace(' ', '+'))

            try:
                url = urlparse.urljoin(self.base_link, url)
                log_utils.log('---VIDNEXT Testing - Exception: \n' + str(url))
                r = client.request(url, headers=self.headers)
                r = client.parseDOM(r, 'li', attrs={'class': 'video-block '})
                r = [re.findall(
                    '<a href="(.+?)">\s*\b*\s*\b*\s*.+?\s*</div>\s*\b*\s*\b*\s*<div class="name">\s*(.+?)\s*<\b*\s*.+?\s*<span class="date">(.+?)-.+?</span>',
                    i, re.DOTALL)[0] for i in r]

                # items += r
            except:
                return

            for item in r:
                log_utils.log('---VIDNEXT Testing - Exception: \n' + str(item))
                if 'tvshowtitle' in data:
                    if hdlr in item[1]:
                        t = urlparse.urljoin(self.base_link, item[0])
                        t = client.request(t, headers=self.headers)
                        t = re.findall('<iframe src="(.+?)"', t)[0]
                        if t.startswith('//'): t = 'https:' + t
                        t = client.request(t, headers={'User-Agent': client.agent(), 'Referer': t})
                        t = re.compile('data-video="(.+?)">.+?</li>').findall(t)
                        t = [i for i in t]
                        items += t
                else:
                    if title in item[1] and data['year'] in item[2]:
                        t = urlparse.urljoin(self.base_link, item[0])
                        t = client.request(t, headers=self.headers)
                        t = re.findall('<iframe src="(.+?)"', t)[0]
                        if t.startswith('//'): t = 'https:' + t
                        t = client.request(t, headers={'User-Agent': client.agent(), 'Referer': t})
                        t = re.compile('data-video="(.+?)">.+?</li>').findall(t)
                        t = [i for i in t]
                        items += t

            for url in items:
                if url.startswith('//'):
                    url = 'https:' + url
                if 'movcloud' in url:
                    url = url.replace('https://movcloud.net/embed/', 'https://api.movcloud.net/stream/')
                    url = client.request(url, headers={'User-Agent': client.agent(), 'Referer': 'https://movcloud.net'})
                    url = json.loads(url)
                    url = url['data']
                    url = url['sources']
                    for url in url:
                        url = url['file']
                        sources.append(
                            {'source': 'movcloud', 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False,
                             'debridonly': False})
                else:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if valid:
                        sources.append(
                            {'source': host, 'quality': 'SD', 'language': 'en', 'url': url, 'direct': False,
                             'debridonly': False})

            return sources
        except Exception:
            failure = traceback.format_exc()
            log_utils.log('---VIDNEXT Testing - Exception: \n' + str(failure))
            return sources

    def resolve(self, url):
        return url
