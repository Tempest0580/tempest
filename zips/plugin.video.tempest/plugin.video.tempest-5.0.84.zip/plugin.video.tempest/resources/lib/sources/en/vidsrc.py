# -*- coding: utf-8 -*-
"""
    **Created by Tempest**
    **If you see this in a addon other than Tempest and says it was
    created by someone other than Tempest they stole it from me**
"""

import re, urllib, urlparse, requests
import traceback
from resources.lib.modules import log_utils
from resources.lib.modules import client


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['v2.vidsrc.me']
        self.base_link = 'https://v2.vidsrc.me'
        self.search_link = '/embed/%s/'
        self.search_link2 = '/embed/%s/%s-%s/'
        self.link = 'https://v2.vidsrc.me/src/%s'
        self.headers = {'User-Agent': client.agent(), 'Referer': self.base_link}

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            items = []

            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            if 'tvshowtitle' in data:
                urls = self.search_link2 % (data['imdb'], data['season'], data['episode'])
            else:
                urls = self.search_link % urllib.quote_plus(data['imdb'])

            try:
                url = urlparse.urljoin(self.base_link, urls)
                posts = requests.get(url, headers=self.headers).content
                r = re.findall('data-hash="(.+?)"', posts)[0]
                r = self.link % r
                url = requests.get(r, headers=self.headers).content
                url = re.findall("'player' src='(.+?)'", url)[0]
                url = url + '|Referer=https://v2.vidsrc.me'
                sources.append(
                    {'source': 'CDN', 'quality': 'SD', 'language': 'en', 'url': url,
                     'direct': False, 'debridonly': False})
            except:
                return

            return sources
        except Exception:
            failure = traceback.format_exc()
            log_utils.log('---VIDSRC Testing - Exception: \n' + str(failure))
            return sources

    def resolve(self, url):
        return url
